"""MetaSleep-Guard automated tests."""
