"""Automatic report generation."""

